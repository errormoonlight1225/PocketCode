// SPDX-License-Identifier: MIT
// Copyright © 2018-2023 WireGuard LLC. All Rights Reserved.

import Foundation

extension TunnelConfiguration {

    enum ParserState {
        case inInterfaceSection
        case inPeerSection
        case notInASection
    }

    enum ParseError: Error {
        case invalidLine(String.SubSequence)
        case noInterface
        case multipleInterfaces
        case interfaceHasNoPrivateKey
        case interfaceHasInvalidPrivateKey(String)
        case interfaceHasInvalidListenPort(String)
        case interfaceHasInvalidAddress(String)
        case interfaceHasInvalidDNS(String)
        case interfaceHasInvalidMTU(String)
        case interfaceHasUnrecognizedKey(String)
        case interfaceHasInvalidCustomParam(String)
        case interfaceHasInvalidHeaderProtectionKey(String)
        case peerHasNoPublicKey
        case peerHasInvalidPublicKey(String)
        case peerHasInvalidPreSharedKey(String)
        case peerHasInvalidAllowedIP(String)
        case peerHasInvalidEndpoint(String)
        case peerHasInvalidPersistentKeepAlive(String)
        case peerHasInvalidTransferBytes(String)
        case peerHasInvalidLastHandshakeTime(String)
        case peerHasUnrecognizedKey(String)
        case multiplePeersWithSamePublicKey
        case multipleEntriesForKey(String)
    }

    convenience init(fromWgQuickConfig wgQuickConfig: String, called name: String? = nil) throws {
        var interfaceConfiguration: InterfaceConfiguration?
        var peerConfigurations = [PeerConfiguration]()

        let lines = wgQuickConfig.split { $0.isNewline }

        var parserState = ParserState.notInASection
        var attributes = [String: String]()

        for (lineIndex, line) in lines.enumerated() {
            var trimmedLine: String
            if let commentRange = line.range(of: "#") {
                trimmedLine = String(line[..<commentRange.lowerBound])
            } else {
                trimmedLine = String(line)
            }

            trimmedLine = trimmedLine.trimmingCharacters(in: .whitespacesAndNewlines)
            let lowercasedLine = trimmedLine.lowercased()

            if !trimmedLine.isEmpty {
                if let equalsIndex = trimmedLine.firstIndex(of: "=") {
                    // Line contains an attribute
                    let keyWithCase = trimmedLine[..<equalsIndex].trimmingCharacters(in: .whitespacesAndNewlines)
                    let key = keyWithCase.lowercased()
                    let value = trimmedLine[trimmedLine.index(equalsIndex, offsetBy: 1)...].trimmingCharacters(in: .whitespacesAndNewlines)
                    let keysWithMultipleEntriesAllowed: Set<String> = ["address", "allowedips", "dns"]
                    if let presentValue = attributes[key] {
                        if keysWithMultipleEntriesAllowed.contains(key) {
                            attributes[key] = presentValue + "," + value
                        } else {
                            throw ParseError.multipleEntriesForKey(keyWithCase)
                        }
                    } else {
                        attributes[key] = value
                    }
                    let interfaceSectionKeys: Set<String> = [
                        "privatekey",
                        "listenport",
                        "address",
                        "dns",
                        "mtu",
                        "jc",
                        "jmin",
                        "jmax",
                        "s1",
                        "s2",
                        "s3",
                        "s4",
                        "h1",
                        "h2",
                        "h3",
                        "h4",
                        "i1",
                        "i2",
                        "i3",
                        "i4",
                        "i5",
                        "headerprotectionkey",
                        "contentpaddingaddition",
                        "rekeyaftertime",
                        "rekeytimeout",
                        "rejectaftertime",
                        "keepalivetimeout",
                        "maxhandshakeattempts",
                        "randomtrailers",
                        "disablecookies",
                    ]
                    let peerSectionKeys: Set<String> = ["publickey", "presharedkey", "allowedips", "endpoint", "persistentkeepalive"]
                    if parserState == .inInterfaceSection {
                        guard interfaceSectionKeys.contains(key) else {
                            throw ParseError.interfaceHasUnrecognizedKey(keyWithCase)
                        }
                    } else if parserState == .inPeerSection {
                        guard peerSectionKeys.contains(key) else {
                            throw ParseError.peerHasUnrecognizedKey(keyWithCase)
                        }
                    }
                } else if lowercasedLine != "[interface]" && lowercasedLine != "[peer]" {
                    throw ParseError.invalidLine(line)
                }
            }

            let isLastLine = lineIndex == lines.count - 1

            if isLastLine || lowercasedLine == "[interface]" || lowercasedLine == "[peer]" {
                // Previous section has ended; process the attributes collected so far
                if parserState == .inInterfaceSection {
                    let interface = try TunnelConfiguration.collate(interfaceAttributes: attributes)
                    guard interfaceConfiguration == nil else { throw ParseError.multipleInterfaces }
                    interfaceConfiguration = interface
                } else if parserState == .inPeerSection {
                    let peer = try TunnelConfiguration.collate(peerAttributes: attributes)
                    peerConfigurations.append(peer)
                }
            }

            if lowercasedLine == "[interface]" {
                parserState = .inInterfaceSection
                attributes.removeAll()
            } else if lowercasedLine == "[peer]" {
                parserState = .inPeerSection
                attributes.removeAll()
            }
        }

        let peerPublicKeysArray = peerConfigurations.map { $0.publicKey }
        let peerPublicKeysSet = Set<PublicKey>(peerPublicKeysArray)
        if peerPublicKeysArray.count != peerPublicKeysSet.count {
            throw ParseError.multiplePeersWithSamePublicKey
        }

        if let interfaceConfiguration = interfaceConfiguration {
            self.init(name: name, interface: interfaceConfiguration, peers: peerConfigurations)
        } else {
            throw ParseError.noInterface
        }
    }

    func asWgQuickConfig() -> String {
        var output = "[Interface]\n"
        output.append("PrivateKey = \(interface.privateKey.base64Key)\n")
        if let listenPort = interface.listenPort {
            output.append("ListenPort = \(listenPort)\n")
        }

        if let junkPacketCount = interface.junkPacketCount {
            output.append("Jc = \(junkPacketCount)\n")
        }
        if let junkPacketMinSize = interface.junkPacketMinSize {
            output.append("Jmin = \(junkPacketMinSize)\n")
        }
        if let junkPacketMaxSize = interface.junkPacketMaxSize {
            output.append("Jmax = \(junkPacketMaxSize)\n")
        }
        if let initPacketJunkSize = interface.initPacketJunkSize {
            output.append("S1 = \(initPacketJunkSize)\n")
        }
        if let responsePacketJunkSize = interface.responsePacketJunkSize {
            output.append("S2 = \(responsePacketJunkSize)\n")
        }
        if let cookieReplyPacketJunkSize = interface.cookieReplyPacketJunkSize {
            output.append("S3 = \(cookieReplyPacketJunkSize)\n")
        }
        if let transportPacketJunkSize = interface.transportPacketJunkSize {
            output.append("S4 = \(transportPacketJunkSize)\n")
        }
        if let initPacketMagicHeader = interface.initPacketMagicHeader {
            output.append("H1 = \(initPacketMagicHeader)\n")
        }
        if let responsePacketMagicHeader = interface.responsePacketMagicHeader {
            output.append("H2 = \(responsePacketMagicHeader)\n")
        }
        if let underloadPacketMagicHeader = interface.underloadPacketMagicHeader {
            output.append("H3 = \(underloadPacketMagicHeader)\n")
        }
        if let transportPacketMagicHeader = interface.transportPacketMagicHeader {
            output.append("H4 = \(transportPacketMagicHeader)\n")
        }
        if let specialJunk1 = interface.specialJunk1 {
            output.append("I1 = \(specialJunk1)\n")
        }
        if let specialJunk2 = interface.specialJunk2 {
            output.append("I2 = \(specialJunk2)\n")
        }
        if let specialJunk3 = interface.specialJunk3 {
            output.append("I3 = \(specialJunk3)\n")
        }
        if let specialJunk4 = interface.specialJunk4 {
            output.append("I4 = \(specialJunk4)\n")
        }
        if let specialJunk5 = interface.specialJunk5 {
            output.append("I5 = \(specialJunk5)\n")
        }
        if let headerProtectionKey = interface.headerProtectionKey {
            output.append("HeaderProtectionKey = \(headerProtectionKey.base64Key)\n")
        }
        if let contentPaddingAddition = interface.contentPaddingAddition {
            output.append("ContentPaddingAddition = \(contentPaddingAddition)\n")
        }
        if let rekeyAfterTime = interface.rekeyAfterTime {
            output.append("RekeyAfterTime = \(rekeyAfterTime)\n")
        }
        if let rekeyTimeout = interface.rekeyTimeout {
            output.append("RekeyTimeout = \(rekeyTimeout)\n")
        }
        if let rejectAfterTime = interface.rejectAfterTime {
            output.append("RejectAfterTime = \(rejectAfterTime)\n")
        }
        if let keepaliveTimeout = interface.keepaliveTimeout {
            output.append("KeepaliveTimeout = \(keepaliveTimeout)\n")
        }
        if let maxHandshakeAttempts = interface.maxHandshakeAttempts {
            output.append("MaxHandshakeAttempts = \(maxHandshakeAttempts)\n")
        }
        if let randomTrailers = interface.randomTrailers {
            output.append("RandomTrailers = \(randomTrailers)\n")
        }
        if let disableCookies = interface.disableCookies {
            output.append("DisableCookies = \(disableCookies)\n")
        }
        if !interface.addresses.isEmpty {
            let addressString = interface.addresses.map { $0.stringRepresentation }.joined(separator: ", ")
            output.append("Address = \(addressString)\n")
        }
        if !interface.dns.isEmpty || !interface.dnsSearch.isEmpty {
            var dnsLine = interface.dns.map { $0.stringRepresentation }
            dnsLine.append(contentsOf: interface.dnsSearch)
            let dnsString = dnsLine.joined(separator: ", ")
            output.append("DNS = \(dnsString)\n")
        }
        if let mtu = interface.mtu {
            output.append("MTU = \(mtu)\n")
        }

        for peer in peers {
            output.append("\n[Peer]\n")
            output.append("PublicKey = \(peer.publicKey.base64Key)\n")
            if let preSharedKey = peer.preSharedKey?.base64Key {
                output.append("PresharedKey = \(preSharedKey)\n")
            }
            if !peer.allowedIPs.isEmpty {
                let allowedIPsString = peer.allowedIPs.map { $0.stringRepresentation }.joined(separator: ", ")
                output.append("AllowedIPs = \(allowedIPsString)\n")
            }
            if let endpoint = peer.endpoint {
                output.append("Endpoint = \(endpoint.stringRepresentation)\n")
            }
            if let persistentKeepAlive = peer.persistentKeepAlive {
                output.append("PersistentKeepalive = \(persistentKeepAlive)\n")
            }
        }

        return output
    }

    private static func collate(interfaceAttributes attributes: [String: String]) throws -> InterfaceConfiguration {
        guard let privateKeyString = attributes["privatekey"] else {
            throw ParseError.interfaceHasNoPrivateKey
        }
        guard let privateKey = PrivateKey(base64Key: privateKeyString) else {
            throw ParseError.interfaceHasInvalidPrivateKey(privateKeyString)
        }
        var interface = InterfaceConfiguration(privateKey: privateKey)
        if let listenPortString = attributes["listenport"] {
            guard let listenPort = UInt16(listenPortString) else {
                throw ParseError.interfaceHasInvalidListenPort(listenPortString)
            }
            interface.listenPort = listenPort
        }
        if let addressesString = attributes["address"] {
            var addresses = [IPAddressRange]()
            for addressString in addressesString.splitToArray(trimmingCharacters: .whitespacesAndNewlines) {
                guard let address = IPAddressRange(from: addressString) else {
                    throw ParseError.interfaceHasInvalidAddress(addressString)
                }
                addresses.append(address)
            }
            interface.addresses = addresses
        }
        if let dnsString = attributes["dns"] {
            var dnsServers = [DNSServer]()
            var dnsSearch = [String]()
            for dnsServerString in dnsString.splitToArray(trimmingCharacters: .whitespacesAndNewlines) {
                if let dnsServer = DNSServer(from: dnsServerString) {
                    dnsServers.append(dnsServer)
                } else {
                    dnsSearch.append(dnsServerString)
                }
            }
            interface.dns = dnsServers
            interface.dnsSearch = dnsSearch
        }
        if let mtuString = attributes["mtu"] {
            guard let mtu = UInt16(mtuString) else {
                throw ParseError.interfaceHasInvalidMTU(mtuString)
            }
            interface.mtu = mtu
        }
        if let junkPacketCountString = attributes["jc"] {
            guard let junkPacketCount = UInt16(junkPacketCountString) else {
                throw ParseError.interfaceHasInvalidCustomParam(junkPacketCountString)
            }
            interface.junkPacketCount = junkPacketCount
        }
        if let junkPacketMinSizeString = attributes["jmin"] {
            guard let junkPacketMinSize = UInt16(junkPacketMinSizeString) else {
                throw ParseError.interfaceHasInvalidCustomParam(junkPacketMinSizeString)
            }
            interface.junkPacketMinSize = junkPacketMinSize
        }
        if let junkPacketMaxSizeString = attributes["jmax"] {
            guard let junkPacketMaxSize = UInt16(junkPacketMaxSizeString) else {
                throw ParseError.interfaceHasInvalidCustomParam(junkPacketMaxSizeString)
            }
            interface.junkPacketMaxSize = junkPacketMaxSize
        }
        if let initPacketJunkSizeString = attributes["s1"] {
            guard let initPacketJunkSize = UInt16(initPacketJunkSizeString) else {
                throw ParseError.interfaceHasInvalidCustomParam(initPacketJunkSizeString)
            }
            interface.initPacketJunkSize = initPacketJunkSize
        }
        if let responsePacketJunkSizeString = attributes["s2"] {
            guard let responsePacketJunkSize = UInt16(responsePacketJunkSizeString) else {
                throw ParseError.interfaceHasInvalidCustomParam(responsePacketJunkSizeString)
            }
            interface.responsePacketJunkSize = responsePacketJunkSize
        }
        if let cookieReplyPacketJunkSizeString = attributes["s3"] {
            guard let cookieReplyPacketJunkSize = UInt16(cookieReplyPacketJunkSizeString) else {
                throw ParseError.interfaceHasInvalidCustomParam(cookieReplyPacketJunkSizeString)
            }
            interface.cookieReplyPacketJunkSize = cookieReplyPacketJunkSize
        }
        if let transportPacketJunkSizeString = attributes["s4"] {
            guard let transportPacketJunkSize = UInt16(transportPacketJunkSizeString) else {
                throw ParseError.interfaceHasInvalidCustomParam(transportPacketJunkSizeString)
            }
            interface.transportPacketJunkSize = transportPacketJunkSize
        }
        if let initPacketMagicHeaderString = attributes["h1"] {
            interface.initPacketMagicHeader = initPacketMagicHeaderString
        }
        if let responsePacketMagicHeaderString = attributes["h2"] {
            interface.responsePacketMagicHeader = responsePacketMagicHeaderString
        }
        if let underloadPacketMagicHeaderString = attributes["h3"] {
            interface.underloadPacketMagicHeader = underloadPacketMagicHeaderString
        }
        if let transportPacketMagicHeaderString = attributes["h4"] {
            interface.transportPacketMagicHeader = transportPacketMagicHeaderString
        }
        if let specialJunk1String = attributes["i1"] {
            interface.specialJunk1 = specialJunk1String
        }
        if let specialJunk2String = attributes["i2"] {
            interface.specialJunk2 = specialJunk2String
        }
        if let specialJunk3String = attributes["i3"] {
            interface.specialJunk3 = specialJunk3String
        }
        if let specialJunk4String = attributes["i4"] {
            interface.specialJunk4 = specialJunk4String
        }
        if let specialJunk5String = attributes["i5"] {
            interface.specialJunk5 = specialJunk5String
        }
        if let headerProtectionKeyString = attributes["headerprotectionkey"], !headerProtectionKeyString.isEmpty {
            guard let headerProtectionKey = PrivateKey(base64Key: headerProtectionKeyString) else {
                throw ParseError.interfaceHasInvalidHeaderProtectionKey(headerProtectionKeyString)
            }
            interface.headerProtectionKey = headerProtectionKey
        }
        if let contentPaddingAdditionString = attributes["contentpaddingaddition"], !contentPaddingAdditionString.isEmpty {
            interface.contentPaddingAddition = contentPaddingAdditionString
        }
        if let rekeyAfterTimeString = attributes["rekeyaftertime"], !rekeyAfterTimeString.isEmpty {
            interface.rekeyAfterTime = rekeyAfterTimeString
        }
        if let rekeyTimeoutString = attributes["rekeytimeout"], !rekeyTimeoutString.isEmpty {
            interface.rekeyTimeout = rekeyTimeoutString
        }
        if let rejectAfterTimeString = attributes["rejectaftertime"], !rejectAfterTimeString.isEmpty {
            interface.rejectAfterTime = rejectAfterTimeString
        }
        if let keepaliveTimeoutString = attributes["keepalivetimeout"], !keepaliveTimeoutString.isEmpty {
            interface.keepaliveTimeout = keepaliveTimeoutString
        }
        if let maxHandshakeAttemptsString = attributes["maxhandshakeattempts"], !maxHandshakeAttemptsString.isEmpty {
            interface.maxHandshakeAttempts = maxHandshakeAttemptsString
        }
        if let randomTrailersString = attributes["randomtrailers"], !randomTrailersString.isEmpty {
            interface.randomTrailers = randomTrailersString
        }
        if let disableCookiesString = attributes["disablecookies"], !disableCookiesString.isEmpty {
            interface.disableCookies = disableCookiesString
        }
        return interface
    }

    private static func collate(peerAttributes attributes: [String: String]) throws -> PeerConfiguration {
        guard let publicKeyString = attributes["publickey"] else {
            throw ParseError.peerHasNoPublicKey
        }
        guard let publicKey = PublicKey(base64Key: publicKeyString) else {
            throw ParseError.peerHasInvalidPublicKey(publicKeyString)
        }
        var peer = PeerConfiguration(publicKey: publicKey)
        if let preSharedKeyString = attributes["presharedkey"] {
            guard let preSharedKey = PreSharedKey(base64Key: preSharedKeyString) else {
                throw ParseError.peerHasInvalidPreSharedKey(preSharedKeyString)
            }
            peer.preSharedKey = preSharedKey
        }
        if let allowedIPsString = attributes["allowedips"] {
            var allowedIPs = [IPAddressRange]()
            for allowedIPString in allowedIPsString.splitToArray(trimmingCharacters: .whitespacesAndNewlines) {
                guard let allowedIP = IPAddressRange(from: allowedIPString) else {
                    throw ParseError.peerHasInvalidAllowedIP(allowedIPString)
                }
                allowedIPs.append(allowedIP)
            }
            peer.allowedIPs = allowedIPs
        }
        if let endpointString = attributes["endpoint"] {
            guard let endpoint = Endpoint(from: endpointString) else {
                throw ParseError.peerHasInvalidEndpoint(endpointString)
            }
            peer.endpoint = endpoint
        }
        if let persistentKeepAliveString = attributes["persistentkeepalive"], !persistentKeepAliveString.isEmpty {
            peer.persistentKeepAlive = persistentKeepAliveString
        }
        return peer
    }

}
