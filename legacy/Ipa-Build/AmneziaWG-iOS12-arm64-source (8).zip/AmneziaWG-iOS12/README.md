# AmneziaWG for iOS 12 (arm64)

非官方源码适配工程，尚未经过 Xcode 编译和真机验证。

请先阅读 [中文说明及验证状态](README-iOS12-zh.md)。

- 原生 UIKit + Packet Tunnel VPN 扩展
- GitHub Actions：`.github/workflows/build-ios12.yml`
- Mac 本机构建：`bash scripts/build-ios12.sh`
- 原项目文档：[README-upstream.md](README-upstream.md)

未签名产物不能直接通过免费 AltStore 获得 VPN 扩展权限。
