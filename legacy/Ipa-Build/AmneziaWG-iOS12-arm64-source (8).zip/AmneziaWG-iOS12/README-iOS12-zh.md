# AmneziaWG iOS 12 arm64 适配工程（待编译验证）

目标：iOS 12.5.8、arm64、非越狱设备。最低部署版本设为 iOS 12.0。
这是非官方修改版，不是官方发布。当前交付是完整源码工程，**不是可直接安装的 IPA**。

## 当前完成情况

- 基于官方 amnezia-vpn/amneziawg-apple 源码提交
  `9d5ee60edefa95b933a738dd7cda671dd18021fc`，保留其许可证。
- 保留原生 UIKit 界面、配置导入、二维码导入、隧道管理与 Packet Tunnel 扩展。
- 保留当前 AmneziaWG v3 核心依赖及配置字段；协议实际连接尚未实测。
- 给 iOS 13 的语义颜色与加载动画增加 iOS 12 回退。
- iOS 14 以下使用 CaptiveNetwork 读取 Wi-Fi 名称；系统无权返回时允许手动填写。
- iOS 15 钥匙串引用迁移仅在相应版本运行。
- 统一 Swift Package / Xcode / Go C 编译参数的 iOS 最低版本。
- 默认不编译 Xray 桥接（用 `xray` 构建标签隔离）；本目标只用 AmneziaWG。
- 移除上游开发者 Team ID，改用独立的示例 Bundle ID。
- 添加共享 Xcode scheme、GitHub Actions 构建流程、未签名 IPA 打包与产物检查。

## 验证状态

已经执行：补丁空白检查、Shell 语法检查、Python 语法检查、产物检查器的五项正反测试、XML/plist 结构解析。

**尚未执行：Xcode 编译、Go iOS 核心编译、有效签名、iOS 12.5.8 真机启动、VPN 握手、DNS/IPv4/IPv6 与断线恢复测试。**
当前执行环境为 Linux，没有 Xcode/iPhoneOS SDK，也没有可用的签名材料。
源码修改并不等于兼容性已通过。构建流程可能暴露其他 API、依赖或工具链问题，需要根据真实日志继续修复。

## 在 GitHub Actions 构建

1. 把本目录内的全部内容提交到自己的 GitHub 仓库根目录。必须包含 `.github/workflows/build-ios12.yml`，不要只把 ZIP 本身上传。
2. 打开仓库 Actions，选择 **Build iOS 12 arm64 (unsigned)**，点击 **Run workflow**。
3. 流程使用 macOS 14、Xcode 16.2、Go 1.26.0。若 GitHub 镜像不再提供该 Xcode 路径，需要选择仍支持 iOS 12 部署目标的完整 Xcode，并重新验证。
4. 成功后下载 `AmneziaWG-iOS12-arm64-unsigned` 构建产物。
5. 失败时下载 `build-diagnostics`，其中的编译日志用于定位错误。

本次没有在任何远程仓库上传代码或执行工作流。

## 在 Mac 本机构建

安装完整 Xcode 和 Go 1.26.x，选中正确的 Xcode，然后在此目录运行：

```bash
bash scripts/build-ios12.sh
```

成功时输出 `dist/AmneziaWG-iOS12-arm64-unsigned.ipa`。
脚本会拒绝缺少 VPN 扩展、非 arm64、模拟器平台，以及声明最低系统高于 iOS 12.5.8 的 Mach-O 文件。
该检查不能证明没有调用旧系统缺失的动态 API，也不能替代真机测试。
为避免拿旧产物误判成功，脚本只会在本次构建和检查均成功后打包。

## 签名与 AltStore

免费 Apple ID 的 AltStore 不能提供此应用所需的 Network Extension 能力。
未签名 IPA 只是构建产物，不能保证通过 AltStore 免费自签后运行 VPN。
主程序和扩展需要各自匹配的有效签名/描述文件、正确的 Bundle ID、Packet Tunnel 权限，以及共享 App Group。
不要删除扩展来绕过安装错误，否则无法建立隧道。

有合适的签名条件后，在 `Sources/WireGuardApp/Config/Developer.xcconfig` 设置自己的 Team ID、App ID；在 Xcode 中为主程序和扩展配置能力与描述文件，再构建签名版本。
不要在仓库中提交证书私钥、账号密码、VPN 私钥或真实配置。

## 真机验收

使用测试服务器/测试配置，在 iOS 12.5.8 上验证：

1. 首次启动、文件/二维码导入和重启后配置保留。
2. 系统 VPN 授权、成功握手与连接状态。
3. DNS、IPv4/IPv6、全局路由与配置指定的分流。
4. Wi-Fi/蜂窝切换、锁屏唤醒、无网络后重连。
5. 停止隧道后恢复正常网络、删除配置不会误删其他配置。

通过编译或看到 VPN 图标均不足以代表以上项目已经通过。
