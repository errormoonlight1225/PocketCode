#!/usr/bin/env python3
"""Negative tests for the compatibility gate (not a VPN or iOS runtime test)."""
import struct
import unittest
from verify_app import check_macho

def fixture(minimum=(12, 0, 0), cpu=0x100000C, platform=2):
    encoded = minimum[0] << 16 | minimum[1] << 8 | minimum[2]
    command = struct.pack('<6I', 0x32, 24, platform, encoded, 0, 0)
    return struct.pack('<8I', 0xFEEDFACF, cpu, 0, 2, 1, len(command), 0, 0) + command

class CompatibilityGate(unittest.TestCase):
    def test_accepts_arm64_ios12(self):
        check_macho(fixture(), 'valid')

    def test_rejects_ios13(self):
        with self.assertRaises(ValueError):
            check_macho(fixture((13, 0, 0)), 'too new')

    def test_rejects_simulator(self):
        with self.assertRaises(ValueError):
            check_macho(fixture(platform=7), 'simulator')

    def test_rejects_wrong_cpu(self):
        with self.assertRaises(ValueError):
            check_macho(fixture(cpu=0x1000007), 'x86_64')

    def test_rejects_truncation(self):
        with self.assertRaises(ValueError):
            check_macho(fixture()[:-1], 'truncated')

if __name__ == '__main__':
    unittest.main()
