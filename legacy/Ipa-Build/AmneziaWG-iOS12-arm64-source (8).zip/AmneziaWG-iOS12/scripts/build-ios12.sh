#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
    echo 'This build requires macOS with full Xcode (iPhoneOS SDK).' >&2
    exit 2
fi
command -v go >/dev/null
xcrun --sdk iphoneos --show-sdk-path >/dev/null
case "$(go env GOVERSION)" in
    go1.26*) ;;
    *) echo 'Use Go 1.26.x for this pinned source revision.' >&2; exit 2 ;;
esac
export GOTOOLCHAIN=local
export GOFLAGS=-mod=readonly
export IPHONEOS_DEPLOYMENT_TARGET=12.0
mkdir -p build dist
xcodebuild -project WireGuard.xcodeproj -scheme AmneziaWG-iOS12 \
    -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
    -derivedDataPath "$PWD/build/DerivedData" \
    ARCHS=arm64 ONLY_ACTIVE_ARCH=NO IPHONEOS_DEPLOYMENT_TARGET=12.0 \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= \
    DEVELOPMENT_TEAM= ENABLE_BITCODE=NO ENABLE_USER_SCRIPT_SANDBOXING=NO \
    build 2>&1 | tee build/xcodebuild.log
app="$PWD/build/DerivedData/Build/Products/Release-iphoneos/AmneziaWG.app"
python3 scripts/verify_app.py "$app" | tee build/verification.txt
# A fresh staging directory prevents stale extensions/files entering the IPA.
stage=$(mktemp -d "$PWD/build/ipa.XXXXXX")
trap 'rm -rf "$stage"' EXIT
mkdir "$stage/Payload"
ditto "$app" "$stage/Payload/AmneziaWG.app"
output="$PWD/dist/AmneziaWG-iOS12-arm64-unsigned.ipa"
rm -f "$output"
(cd "$stage" && zip -qry "$output" Payload)
shasum -a 256 "$output" > "$output.sha256"
echo "Created unsigned package: $output"
echo 'Signing with Network Extension and App Group provisioning is still required.'
