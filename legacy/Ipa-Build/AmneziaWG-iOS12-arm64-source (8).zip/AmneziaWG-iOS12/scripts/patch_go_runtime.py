#!/usr/bin/env python3
"""Apply upstream's Darwin sleep-aware clock change to a private GOROOT copy."""
from pathlib import Path
import sys

root = Path(sys.argv[1]) / "src/runtime"
paths = [root / name for name in (
    "sys_darwin.go", "sys_darwin_amd64.s", "sys_darwin_arm64.s"
)]
old = "libc_mach_absolute_time"
new = "libc_mach_continuous_time"
texts = [p.read_text() for p in paths]
if not all(old in text or new in text for text in texts):
    raise SystemExit("Unrecognized Go runtime clock implementation; manual review required")
for path, text in zip(paths, texts):
    path.write_text(text.replace(old, new).replace(
        'mach_absolute_time "/usr/lib/libSystem.B.dylib"',
        'mach_continuous_time "/usr/lib/libSystem.B.dylib"'))
print("Darwin runtime uses sleep-aware mach_continuous_time")
