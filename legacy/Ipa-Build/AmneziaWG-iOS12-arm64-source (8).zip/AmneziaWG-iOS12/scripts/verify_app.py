#!/usr/bin/env python3
"""Inspect built app/extension and every embedded Mach-O, without executing it.

This rejects incompatible minimum OS declarations. It cannot establish runtime
API availability, correct provisioning, or successful VPN operation.
"""
from pathlib import Path
import plistlib
import struct
import sys

def check_macho(data, name):
    if len(data) < 32 or data[:4] != b'\xcf\xfa\xed\xfe':
        raise ValueError(f'{name}: expected thin 64-bit little-endian Mach-O')
    magic, cpu, subtype, kind, count, size, flags, reserved = struct.unpack_from('<8I', data)
    if cpu != 0x100000C:
        raise ValueError(f'{name}: not arm64')
    pos = 32
    limit = pos + size
    if limit > len(data):
        raise ValueError(f'{name}: truncated load commands')
    versions = []
    for _ in range(count):
        command, length = struct.unpack_from('<II', data, pos)
        if length < 8 or pos + length > limit:
            raise ValueError(f'{name}: invalid load command')
        if command == 0x25:  # LC_VERSION_MIN_IPHONEOS
            versions.append(struct.unpack_from('<I', data, pos + 8)[0])
        if command == 0x32:  # LC_BUILD_VERSION
            platform, minimum = struct.unpack_from('<II', data, pos + 8)
            if platform != 2:
                raise ValueError(f'{name}: platform is not iPhoneOS')
            versions.append(minimum)
        pos += length
    if pos != limit or not versions:
        raise ValueError(f'{name}: missing or malformed minimum OS information')
    if any(v > (12 << 16 | 5 << 8 | 8) for v in versions):
        raise ValueError(f'{name}: requires newer than iOS 12.5.8')
    return versions

def verify(app):
    extension = app / 'PlugIns/WireGuardNetworkExtension.appex'
    if not extension.is_dir():
        raise ValueError('VPN extension is missing')
    ids = []
    for bundle in (app, extension):
        info = plistlib.loads((bundle / 'Info.plist').read_bytes())
        minimum = tuple(map(int, info['MinimumOSVersion'].split('.')))
        if (minimum + (0, 0, 0))[:3] > (12, 5, 8):
            raise ValueError(f'{bundle.name}: incompatible Info.plist')
        ids.append(info['CFBundleIdentifier'])
        exe = bundle / info['CFBundleExecutable']
        check_macho(exe.read_bytes(), str(exe))
    if ids[1] != ids[0] + '.network-extension':
        raise ValueError('App and extension identifiers do not match')
    macho_magics = {b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xcf',
                    b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca', b'\xca\xfe\xba\xbf'}
    total = 0
    for path in app.rglob('*'):
        if path.is_file():
            with path.open('rb') as stream:
                magic = stream.read(4)
            if magic in macho_magics:
                check_macho(path.read_bytes(), str(path))
                total += 1
    print(f'PASS: {total} arm64 Mach-O files, minimum OS <= 12.5.8; VPN extension present')
    print('Not verified: signing, dynamic API availability, device launch, tunnel handshake, DNS/routing.')

if __name__ == '__main__':
    verify(Path(sys.argv[1]))
